<!DOCTYPE html>
<html>
<head>

	<title>Admin page</title>
	<link rel="stylesheet" type="text/css" href="button.css">
	<script type="text/javascript">
	</script>
	<style>
		div{
	  		font-size: 20px;
		  	text-align: center;
		  	background-color: lightblue 
		}
		tr{
			background-color: teal;
		}
		table{
			background-color:  lightblue;
			text-align: center;
			padding: 20px;
		}
		button{
	  		background-color: #4CAF50;
			border: 3;
			color: white;
			padding: 10px 20px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
		}
	</style>
</head>
<?php
$servername = "localhost";
$database = "admin page";
$username = "root";
$password = "";

// Create connection

$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
global $conn;
if ($conn==false) {
die("Connection failed: " . mysqli_connect_error());
}

?>


<body bgcolor="green">
	<h1 align="center" style="background-color: #6CDFB7; font-size: 40px; padding: 20px;">ADMIN PAGE</h1>
	
	<hr>
	<p align="right"><button type="submit">Log Out</button></p>
	<h2 align="right"><i>Welcome, Satyajeet</i></h2> 
	
	<hr>
	<div>
	<img src="building.jpg" width="400" height="400">
	<img src="buidling2.jpg" width="400" height="400">
	<img src="building3.jpg" width="400" height="400">	
	</div>
	<hr>
	<div>
	<form action='test.php' method="post" name='property'>
		<label>Choose a site:</label>
		<select id="prop" name="prop">
		<option value='site 23'>Site 23</option>
		<option value='site 24'>Site 24</option>
	</select>
		<button type="submit" name="submit">Submit</button>
	</form>
	</div>
	<?php
	session_start();
	
	// Set session variables
	if(!isset($_POST['prop']))
	{
		$prop = $_SESSION['prop'];
	}
	else{
		$_SESSION['prop']=$_POST["prop"];
		$prop=$_POST["prop"];
	}
	
	?>
	<p><marquee><h2><?php echo $prop; ?></h2></marquee></p>
	<p align="center"><h2>SITE WORKERS:-</h2></p>
	<table border="1" cellpadding="4" align="center">
		<tr>
    		<th>Name</th>
    		<th>Position</th>
    		<th>No. of Leaves</th>
    		<th>Salary</th>
    		<th>Festival Bonus</th>
    		<th>Calculated Salary</th>
 		</tr>
 		<?php
 		// if(!isset($_POST["prop"]))
 		// {
 		// 	$prop = 'site 24';
 		// }
 		// else{
 		// $prop = $_POST["prop"];}
 		$result = mysqli_query($conn, "SELECT * from workers");	
		if ($result->num_rows > 0) {
 		
  		while($row = mysqli_fetch_array($result) ) {
  			$sal = $row['salary']+$row['bonus'];
   	 		if($row['property']==$prop) {  	 		
 
			echo "<tr>";
	    	echo "<td>".$row['Name']."</td>";
	    	echo "<td>".$row['Position']."</td>";
	    	echo "<td>".$row['leaves']."</td>";
	    	echo "<td>".$row['salary']."</td>";
	    	echo "<td>".$row['bonus']."</td>";
	    	echo "<td>".$sal."</td>";
	  		echo"</tr>";
   	 	
 		 }

 		 }
 		}

 		?>
	</table>
	<br>

<p align="center"><h2>Site Orders:</h2></p>
		<div>
		<form method="POST" action="test.php" >
		<hr>
	<?php
	
	
	
	$result = mysqli_query($conn, "SELECT * from orders");	
		if ($result->num_rows > 0) {
 		// echo"<hr>";
  	while($row = mysqli_fetch_array($result) ) {
  		
   	 	if($row['Status']==0 && $row['Site']==$prop) {
   	 		$num = $row['Number'];
   	 		# code...
   	 		
	
   	 		
   	 		printf($row['Number']);
  			echo "<hr>";
   	 		echo "<li>By Site Manager:". $row['Name']."</li>";
   	 		echo "<p>".$row['Order']."</p>";
   	 		
   	 		echo "<p><button name='accept".$num."' type='submit' >Accept</button> <button  type='submit' name='reject".$num."'>Reject</button></p>";
 		 

		if(isset($_POST['accept'.$num.''])){

		        
		        if(mysqli_query($conn, 'UPDATE orders SET status = 1 WHERE Number ='. $num))
				{
					echo "<b>Order Number ".$num." has been accepted :)"."</b><hr>";

					}
				else{
					echo("Changes failed to be made :/");
					
				}
				
				 unset($_POST['accept']);
		    }
		    
		   else if(isset($_POST['reject'.$num.''])){
		        

		        if(mysqli_query($conn, 'UPDATE orders SET status = -1 WHERE Number ='. $num))
				{
					echo "<b>Order Number ".$num." has been rejected :)"."</b><hr>";
					}
				else{
					echo("Changes failed to be made :/");
					
				}
				 unset($_POST['reject']);


		    }
		    else {
		    	echo"<hr>";
		    }
		    }
 		 }
 		 
}



    


		?>

	</form>
	</div>
</body>
</html>